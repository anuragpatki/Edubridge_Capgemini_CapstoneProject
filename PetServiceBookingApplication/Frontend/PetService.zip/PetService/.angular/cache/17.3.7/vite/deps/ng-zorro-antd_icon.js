import {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService
} from "./chunk-O3BRA3QG.js";
import "./chunk-K3B7IP7G.js";
import "./chunk-DCXYKRNZ.js";
import "./chunk-NLOAL77L.js";
import "./chunk-6B6RHT45.js";
import "./chunk-OTK7LJ7X.js";
import "./chunk-VCFGKTIQ.js";
import "./chunk-2TLIOTXN.js";
import "./chunk-JKR55PDT.js";
import "./chunk-J4B6MK7R.js";
export {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService
};
//# sourceMappingURL=ng-zorro-antd_icon.js.map
