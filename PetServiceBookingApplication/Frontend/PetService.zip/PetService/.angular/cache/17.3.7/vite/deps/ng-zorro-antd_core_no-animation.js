import {
  NzNoAnimationDirective,
  NzNoAnimationModule
} from "./chunk-EEDMGYFP.js";
import "./chunk-S6BFUKGV.js";
import "./chunk-3ZT4GPEH.js";
import "./chunk-RRENOESL.js";
import "./chunk-K3B7IP7G.js";
import "./chunk-DCXYKRNZ.js";
import "./chunk-VCFGKTIQ.js";
import "./chunk-2TLIOTXN.js";
import "./chunk-JKR55PDT.js";
import "./chunk-J4B6MK7R.js";
export {
  NzNoAnimationDirective,
  NzNoAnimationModule
};
//# sourceMappingURL=ng-zorro-antd_core_no-animation.js.map
