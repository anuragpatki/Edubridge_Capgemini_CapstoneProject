import {
  NzProgressComponent,
  NzProgressModule
} from "./chunk-F2QEFQ4G.js";
import "./chunk-WSE5ID6N.js";
import "./chunk-O3BRA3QG.js";
import "./chunk-K3B7IP7G.js";
import "./chunk-DCXYKRNZ.js";
import "./chunk-NLOAL77L.js";
import "./chunk-SDR6KCHG.js";
import "./chunk-6B6RHT45.js";
import "./chunk-OTK7LJ7X.js";
import "./chunk-VCFGKTIQ.js";
import "./chunk-2TLIOTXN.js";
import "./chunk-JKR55PDT.js";
import "./chunk-J4B6MK7R.js";
export {
  NzProgressComponent,
  NzProgressModule
};
//# sourceMappingURL=ng-zorro-antd_progress.js.map
