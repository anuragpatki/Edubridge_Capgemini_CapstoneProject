import {
  NzSpinComponent,
  NzSpinModule
} from "./chunk-A3IG36AF.js";
import "./chunk-SDR6KCHG.js";
import "./chunk-6B6RHT45.js";
import "./chunk-OTK7LJ7X.js";
import "./chunk-VCFGKTIQ.js";
import "./chunk-2TLIOTXN.js";
import "./chunk-JKR55PDT.js";
import "./chunk-J4B6MK7R.js";
export {
  NzSpinComponent,
  NzSpinModule
};
//# sourceMappingURL=ng-zorro-antd_spin.js.map
