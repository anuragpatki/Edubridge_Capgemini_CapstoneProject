import {
  NzTransButtonDirective,
  NzTransButtonModule
} from "./chunk-5OR274TY.js";
import "./chunk-2TLIOTXN.js";
import "./chunk-JKR55PDT.js";
import "./chunk-J4B6MK7R.js";
export {
  NzTransButtonDirective,
  NzTransButtonModule
};
//# sourceMappingURL=ng-zorro-antd_core_trans-button.js.map
