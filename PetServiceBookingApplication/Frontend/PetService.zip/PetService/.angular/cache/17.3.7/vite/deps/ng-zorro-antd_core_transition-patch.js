import {
  NzTransitionPatchDirective,
  NzTransitionPatchModule
} from "./chunk-USQFI56X.js";
import "./chunk-2TLIOTXN.js";
import "./chunk-JKR55PDT.js";
import "./chunk-J4B6MK7R.js";
export {
  NzTransitionPatchDirective as ɵNzTransitionPatchDirective,
  NzTransitionPatchModule as ɵNzTransitionPatchModule
};
//# sourceMappingURL=ng-zorro-antd_core_transition-patch.js.map
