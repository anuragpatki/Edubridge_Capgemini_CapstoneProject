import {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
} from "./chunk-WGRL3HJ2.js";
import "./chunk-S6BFUKGV.js";
import "./chunk-3ZT4GPEH.js";
import "./chunk-RRENOESL.js";
import "./chunk-K3B7IP7G.js";
import "./chunk-DCXYKRNZ.js";
import "./chunk-NLOAL77L.js";
import "./chunk-VCFGKTIQ.js";
import "./chunk-2TLIOTXN.js";
import "./chunk-JKR55PDT.js";
import "./chunk-J4B6MK7R.js";
export {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
};
//# sourceMappingURL=ng-zorro-antd_core_wave.js.map
