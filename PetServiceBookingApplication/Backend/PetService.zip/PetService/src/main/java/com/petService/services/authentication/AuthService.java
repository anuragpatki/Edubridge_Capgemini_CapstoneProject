package com.petService.services.authentication;

import com.petService.dto.SignupRequestDTO;
import com.petService.dto.UserDto;

public interface AuthService {
	
	UserDto signupClient(SignupRequestDTO signupRequestDTO);
	
	public boolean presentByEmail(String email);
	
	public UserDto signupCompany(SignupRequestDTO signupRequestDTO);
}
