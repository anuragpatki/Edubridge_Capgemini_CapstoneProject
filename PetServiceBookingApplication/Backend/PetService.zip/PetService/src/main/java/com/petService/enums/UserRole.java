package com.petService.enums;

public enum UserRole {
	CLIENT,
	
	COMPANY
}
