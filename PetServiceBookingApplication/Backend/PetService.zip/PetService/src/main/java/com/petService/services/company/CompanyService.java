package com.petService.services.company;

import java.util.List;

import com.petService.dto.AdDTO;
import com.petService.dto.ReservationDTO;

import io.jsonwebtoken.io.IOException;

public interface CompanyService {

	boolean postAd(Long userID, AdDTO adDTO) throws IOException, java.io.IOException;
	
	List<AdDTO> getAllAds(Long userId);
	
	AdDTO getAdById(Long adId);
	
	boolean updateAd(Long adId, AdDTO adDTO) throws IOException, java.io.IOException;
	
	boolean deleteAd(Long adId);
	
	List<ReservationDTO> getAllBookings(Long companyId);
	
	boolean changeBookingStatus (Long bookingId, String status);
}
