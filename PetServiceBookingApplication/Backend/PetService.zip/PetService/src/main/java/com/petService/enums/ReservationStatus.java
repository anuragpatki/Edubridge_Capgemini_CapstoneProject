package com.petService.enums;

public enum ReservationStatus {

	PENDING,
	
	APPROVED,
	
	REJECTED
}
