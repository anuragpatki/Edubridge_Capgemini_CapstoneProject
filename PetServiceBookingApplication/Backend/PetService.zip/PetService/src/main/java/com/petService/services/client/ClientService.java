package com.petService.services.client;

import java.util.List;

import com.petService.dto.AdDTO;
import com.petService.dto.AdDetailsForClientDTO;
import com.petService.dto.ReservationDTO;
import com.petService.dto.ReviewDTO;

public interface ClientService {
	
	List<AdDTO> getAllAds();
	
	List<AdDTO> searchAdByName(String name);
	
	boolean bookService(ReservationDTO reservationDTO);
	
	AdDetailsForClientDTO getAdDetailsById(Long adId);
	
	List<ReservationDTO> getAllBookingsByUserId(Long userId);
	
	Boolean giveReview(ReviewDTO reviewDTO);
}
