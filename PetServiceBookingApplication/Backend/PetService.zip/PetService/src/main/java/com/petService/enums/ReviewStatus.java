package com.petService.enums;

public enum ReviewStatus {
	
	TRUE,
	
	FALSE

}
